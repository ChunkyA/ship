package ship;

public class Zerstörer extends Ship {

	public Zerstörer(int size,String typ) {
		super(3,"Zerstöre");
	}

}
