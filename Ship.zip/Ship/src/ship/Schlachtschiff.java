package ship;

public class Schlachtschiff extends Ship {

	public Schlachtschiff(int size,String typ) {
		super(5,"Schlachtschiff");

	}

}
