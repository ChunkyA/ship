package ship;

public class Kreuzer extends Ship {

	public Kreuzer(int size,String typ) {
		super(4,"Kreuze");
	}

}
