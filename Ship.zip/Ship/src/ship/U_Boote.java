package ship;

public class U_Boote extends Ship {

	public U_Boote(int size, String typ) {
		super(2,"U Boote");
	}

}
